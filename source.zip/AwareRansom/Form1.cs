using System.IO;
using System.Security.Principal;

namespace AwareRansom
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            progressBar1.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Show();
            progressBar1.Maximum = 100;
            progressBar1.Value = 100;
            progressBar1.Refresh();

            // Get the current user's name
            string userName = WindowsIdentity.GetCurrent().Name;

            // Create the file on the desktop
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, "Note.txt");
            File.WriteAllText(filePath, "Hey watch out about downloading stuff it can look legit like this but you can still get infected makes sure all your passwords are uniqe and contain a mic of number letters and special characters also make sure to have antivirus software in your computer i recommend Eset + Malwarebytes Anyways stay safe this program is not a virus but a fake virus to spread awareness hint the name awe");
        }
    }
}
